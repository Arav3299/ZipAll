package com.prodian.test.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.prodian.test.modal.Student;
import com.prodian.test.repository.StudentRepository;

@RestController
@RequestMapping("/api/student")
public class StudentController {

	@Autowired
	private StudentRepository studentRepository;
	
	@GetMapping("/get")
	private List<Student> getEmployee(){
		
		List<Student> list = (List<Student>) studentRepository.findAll();
		
		return list;
		
	}
	
	@PostMapping("/save")
	private ResponseEntity<Student> saveStudent(@RequestBody Student student){
		
		return new ResponseEntity<Student>(studentRepository.save(student),HttpStatus.OK);
		
	}
//	
//	@PutMapping("/edit")
//	private ResponseEntity<Student> updateStudent(@RequestBody Student student){
//		
//		return new ResponseEntity<Student>(studentRepository.save(student),HttpStatus.OK);
//		
//	} 
	
	@DeleteMapping("/delete/{studentId}")
	private ResponseEntity<String> deleteStudent(@PathVariable("studentId") int studentId){
		
		Student student = studentRepository.findById(studentId).get();
		
		studentRepository.delete(student);
		return new ResponseEntity<String>("Details's deleted from Database",HttpStatus.OK);
	}
	
	
	
	
	
	
}
