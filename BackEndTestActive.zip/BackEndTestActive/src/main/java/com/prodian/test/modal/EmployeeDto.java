package com.prodian.test.modal;

import lombok.Data;

@Data
public class EmployeeDto {
	
 
	
	 
	private String name;
	
 
 
 
	private String status;

}
