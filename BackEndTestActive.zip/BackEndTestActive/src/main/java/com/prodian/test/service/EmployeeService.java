package com.prodian.test.service;

import java.util.List;

import com.prodian.test.modal.Employee;
import com.prodian.test.modal.EmployeeDto;

public interface EmployeeService {

	List<EmployeeDto> getAllStatusEmployee(String status);

}
