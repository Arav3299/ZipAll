package com.prodian.test.serviceimpl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prodian.test.modal.Employee;
import com.prodian.test.modal.EmployeeDto;
import com.prodian.test.repository.EmployeeRepository;
import com.prodian.test.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public List<EmployeeDto> getAllStatusEmployee(String status) {
	
		List<Employee> list =  employeeRepository.find(status);
		
		List<EmployeeDto> dto = list.stream().map(e -> convertEmployeeToDto(e)).collect(Collectors.toList());
		
		return dto;
		//return list;
	}
	
	private EmployeeDto convertEmployeeToDto(Employee employee) {
		
		EmployeeDto dto = new EmployeeDto();
		
		dto.setName(employee.getName());
		dto.setStatus(employee.getStatus());
		
		return dto;
		
	}

}
