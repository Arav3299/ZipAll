package com.prodian.test.service;

import java.util.List;

import com.prodian.test.modal.Company;

public interface CompanyService {

	Company registerCompany(Company company);

	List<Company> getAllCompanies();

	void deleteCompany(int companyId);

	Company getCompanyById(int companyId);

}
