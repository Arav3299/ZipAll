package com.prodian.test.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prodian.test.modal.Company;

public interface CompanyRepository extends JpaRepository<Company, Integer> {

}
