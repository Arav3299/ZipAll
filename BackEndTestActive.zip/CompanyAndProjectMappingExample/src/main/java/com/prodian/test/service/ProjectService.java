package com.prodian.test.service;

import java.util.List;

import com.prodian.test.modal.Project;

public interface ProjectService {

	Project assignProject(Project project, int companyId);

	List<Project> getAllProjects();

	void deleteProject(int projectId);

	List<Project> getProjectByCompanyId(int companyId);

}
