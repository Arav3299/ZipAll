package com.prodian.test.modal;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import lombok.Data;

@Entity
@Table(name="project_table")
@Data
public class Project {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="project_id")
	private int projectId;
	
	private String projectName;
	
	private int projectDuration;
	
	private String projectWorth;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="company_id")
	@OnDelete(action = OnDeleteAction.CASCADE)
	private Company company;
	 
	
	
	

}
