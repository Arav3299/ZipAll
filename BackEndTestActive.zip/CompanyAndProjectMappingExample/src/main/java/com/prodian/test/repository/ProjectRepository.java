package com.prodian.test.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.prodian.test.modal.Company;
import com.prodian.test.modal.Project;

public interface ProjectRepository extends JpaRepository<Project, Integer> {

	@Query(value="select * from project_table where company_id=:n",nativeQuery=true)
	List<Project> getAllProjectsByCompanyId(@Param("n") int company);
	
	
}
