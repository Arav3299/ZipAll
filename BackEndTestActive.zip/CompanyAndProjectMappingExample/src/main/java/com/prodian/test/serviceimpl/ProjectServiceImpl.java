package com.prodian.test.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prodian.test.modal.Project;
import com.prodian.test.repository.ProjectRepository;
import com.prodian.test.service.CompanyService;
import com.prodian.test.service.ProjectService;


@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectRepository projectRepository;
	
	@Autowired
	private CompanyService companyService;
	
	@Override
	public Project assignProject(Project project, int companyId) {
		
		project.setCompany(companyService.getCompanyById(companyId));
		
		return projectRepository.save(project);
	}

	@Override
	public List<Project> getAllProjects() {
		
		System.out.println("jiii"+projectRepository.getAllProjectsByCompanyId(6));
		return projectRepository.findAll();
		
	}

	@Override
	public void deleteProject(int projectId) {
		Project project = projectRepository.findById(projectId).get();
		
		projectRepository.delete(project);
		
	}

	@Override
	public List<Project> getProjectByCompanyId(int companyId) {
		
		return projectRepository.getAllProjectsByCompanyId(companyId);
	}
	
	

}
