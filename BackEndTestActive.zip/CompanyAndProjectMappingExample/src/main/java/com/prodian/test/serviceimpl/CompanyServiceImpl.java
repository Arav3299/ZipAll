package com.prodian.test.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prodian.test.modal.Company;
import com.prodian.test.repository.CompanyRepository;
import com.prodian.test.service.CompanyService;

@Service
public class CompanyServiceImpl implements CompanyService  {

	
	@Autowired
	private CompanyRepository companyRepository;
	
	
	@Override
	public Company registerCompany(Company company) {
		
		return companyRepository.save(company);
	
	}

	@Override
	public List<Company> getAllCompanies() {
		
		return companyRepository.findAll();
	}

	@Override
	public void deleteCompany(int companyId) {
		
		Company company =  companyRepository.findById(companyId).get();
		companyRepository.delete(company);
		
		
	}

	@Override
	public Company getCompanyById(int companyId) {
		 
		return companyRepository.findById(companyId).get();
	}

}
